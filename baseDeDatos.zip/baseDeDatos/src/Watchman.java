//CELADOR
public class Watchman extends Person {


    public String getWeapon() {
        return weapon;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }



    private String weapon;
    private double workday;

    public double getWorkday() {
        return workday;
    }

    public void setWorkday(double workday) {
        this.workday = workday;
    }
    @Override
    public String toString() {
        return super.toString() +
                "weapon='" + weapon + '\'' +
                ", weapon='" + weapon + '\'' +
                '}';
    }


}

