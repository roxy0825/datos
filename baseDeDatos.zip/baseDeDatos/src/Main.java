import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        List<Watchman> watchmens = new ArrayList();
        List<CleaningStaff> cleaningStaffs = new ArrayList();
        List<Accountant> accountants = new ArrayList();
        List<Admin> admins = new ArrayList();

        String respuesta = "Si";


        while (respuesta.equals("Si")) {
            System.out.println("Digite para ingresar 1= Watchman, 2= CleaningStaff, 3= Accountant, 4= Admin," +
                    "5=salir," +
                    " 6=mostrar Watchman,7=mostrar CleaningStaff, 8=mostrar Accountant,9= mostrar Admin," +
                    " 10= Buscar Watchman");

            int opction = Integer.parseInt(teclado.nextLine());

            if (opction == 1) {
                Watchman watchman = new Watchman();

                System.out.println("Digite su nombre:");
                String name = teclado.nextLine();
                watchman.setName(name);

                System.out.println("Digite su identificacion:");
                String identification = teclado.nextLine();
                watchman.setIdentification(identification);

                System.out.println("Digite su edad:");
                int age = teclado.nextInt();
                watchman.setAge(age);

                System.out.println("Digite tipo de arma:");
                String weapon = teclado.nextLine();
                watchman.setWeapon(teclado.nextLine());

                System.out.println("Digite los dias que trabaja:");
                watchman.setWorkday(Double.parseDouble(teclado.nextLine()));

                watchmens.add(watchman);

            } else if (opction == 2) {
                CleaningStaff cleaningStaff = new CleaningStaff();

                System.out.println("Digite su nombre:");
                String name = teclado.nextLine();
                cleaningStaff.setName(name);

                System.out.println("Digite su identificacion:");
                String identification = teclado.nextLine();
                cleaningStaff.setIdentification(identification);

                System.out.println("Digite su edad:");
                int age = teclado.nextInt();
                cleaningStaff.setAge(age);

                System.out.println("Digite su dia libre:");
                String dayOff = teclado.nextLine();
                cleaningStaff.setDayOff(teclado.nextLine());

                cleaningStaffs.add(cleaningStaff);

            } else if (opction == 3) {
                Accountant accountant = new Accountant();

                System.out.println("Digite su nombre:");
                String name = teclado.nextLine();
                accountant.setName(name);

                System.out.println("Digite su identificacion:");
                String identification = teclado.nextLine();
                accountant.setIdentification(identification);

                System.out.println("Digite su edad:");
                int age = teclado.nextInt();
                accountant.setAge(age);

                System.out.println("nombre del lider:");
                String leader = teclado.nextLine();
                accountant.setLeader(teclado.nextLine());

                System.out.println("nombre del estacionamiento:");
                String parking = teclado.nextLine();
                accountant.setParking(teclado.nextLine());

                accountants.add(accountant);
            } else if (opction == 4) {
                Admin admin = new Admin();

                System.out.println("Digite su nombre:");
                String name = teclado.nextLine();
                admin.setName(name);

                System.out.println("Digite su identificacion:");
                String identification = teclado.nextLine();
                admin.setIdentification(identification);

                System.out.println("Digite su edad:");
                int age = teclado.nextInt();
                admin.setAge(age);

                System.out.println("nombre del lider:");
                String leader = teclado.nextLine();
                admin.setLeader(teclado.nextLine());

                System.out.println("nombre del estacionamiento:");
                String parking = teclado.nextLine();
                admin.setParking(teclado.nextLine());

                admins.add(admin);

            } else if (opction == 6) {
                for (int i = 0; i < watchmens.size(); i++) {
                    System.out.println("NOMBRE DE CELADOR: " + watchmens.get(i).getName() + "\nIDENTIFICACION: " + watchmens.get(i).getIdentification() +
                            "\nEDAD: " + watchmens.get(i).getAge() + "\nARMA: "  + watchmens.get(i).getWeapon() + "\nDIAS TRABAJADOR: " + watchmens.get(i).getWorkday());
                }

            } else if (opction == 7) {
                for (int i = 0; i < cleaningStaffs.size(); i++) {
                    System.out.println("NOMBRE DEl LIMPIADOR " + cleaningStaffs.get(i).getName() + "\nIDENTIFICACION: " +  cleaningStaffs.get(i).getIdentification() +
                            "\nEDAD: " +  cleaningStaffs.get(i).getAge() + "\nDIA LIBRE: "  +  cleaningStaffs.get(i).getDayOff());
                }
            } else if (opction == 8) {
                for (int i = 0; i < accountants.size(); i++) {
                    System.out.println("NOMBRE DEl CONTADOR " + accountants.get(i).getName() + "\nIDENTIFICACION: " +  accountants.get(i).getIdentification() +
                            "\nEDAD: " +  accountants.get(i).getAge() + "\nNOMBRE DEL LIDER: "  +  accountants.get(i).getLeader() + "\n LUGAR DE ESTACIONAMIENTO: " + accountants.get(i).getParking());
                }

            } else if (opction == 9) {
                for (int i = 0; i < admins.size(); i++) {
                    System.out.println("NOMBRE DEl ADMINISTRADOR " + admins.get(i).getName() + "\nIDENTIFICACION: " +  admins.get(i).getIdentification() +
                            "\nEDAD: " +  admins.get(i).getAge() + "\nNOMBRE DEL LIDER: "  +  admins.get(i).getLeader() + "\n LUGAR DE ESTACIONAMIENTO: " + admins.get(i).getParking());
                }
                //SI SE DESEA BUSCAR POR NUMERO DE IDENTIFICACION
            } else if (opction == 10) {
                System.out.println("ingrese el numero de identificacion que desea buscar:");
                String identificationsearch = teclado.nextLine();
                boolean flag = false;

                for (Watchman watc : watchmens) {
                    if (watc.getIdentification().equals(identificationsearch)) {
                        System.out.println("el nombre es" + watc.getName());
                        flag = true;

                        break;
                    }
                }
                if (flag == false) {
                    System.out.println("NO EXISTE");
                }

            } else {
                break;
            }
        }
    }
}

